package com.example.akosombotour;

import android.content.Context;

import java.util.ArrayList;

public class HotelsModel {
    private final String history;

    public HotelsModel(String history) {
        this.history = history;
    }

    public String getHistory() {
        return history;
    }

    public static ArrayList<HotelsModel> getUsers(Context context) {
        ArrayList<HotelsModel> history = new ArrayList<HotelsModel>();
        return history;
    }
}
