package com.example.akosombotour;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class ToursitesAdapter extends ArrayAdapter<ToursitesModel> {

    public ToursitesAdapter(Context context, ArrayList<HashMap<String, String>> data, int historyad, String[] from, int[] to) {
        super(context, 0, historyad);
    }

   @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        ToursitesModel historyad = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.toursites, parent, false);
        }
        // Lookup view for data population
        TextView tvToursites = (TextView) convertView.findViewById(R.id.textview_Toursites);
        TextView ivToursites = (TextView) convertView.findViewById(R.id.textview_Toursites);
        // Populate the data into the template view using the data object
        tvToursites.setText(historyad.getHistory());
        ivToursites.setText(historyad.getHistory());

        // Return the completed view to render on screen
        return convertView;
    }
}

