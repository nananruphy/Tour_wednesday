package com.example.akosombotour;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.fragment.app.ListFragment;

import java.util.ArrayList;
import java.util.HashMap;

public class ToursitesFragment extends ListFragment {
    int[] toursitesImage = {R.drawable.adomi, R.drawable.akosombodam, R.drawable.adomi, R.drawable.akosombodam,R.drawable.adomi};
    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
    ToursitesAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        String[] toursitesName = getResources().getStringArray(R.array.toursitesName);
        //MAP
        HashMap<String, String> map = new HashMap<String, String>();

        //FILL
        for (int i = 0; i < toursitesName.length; i++) {
            map = new HashMap<String, String>();
            map.put("ToursitesName", toursitesName[i]);
            map.put("ToursitesImage", Integer.toString(toursitesImage[i]));

            data.add(map);
        }
        //KEYS IN MAP
        String[] from = {"ToursitesName", "ToursitesImage"};

        //IDS OF VIEWS
        int[] to = {R.id.textview_Toursites, R.id.imageview_Toursites};

        //ADAPTER
         adapter = new ToursitesAdapter(getActivity(), data, R.layout.toursites,from, to);
        setListAdapter(adapter);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> av, View view, int i, long id) {
                if (i == 0) {
                    Intent intent = new Intent(getActivity(), TourImages.class);
                    startActivity(intent);
                }
                if (i == 1) {
                    Intent intent = new Intent(getActivity(), TourImages1.class);
                    startActivity(intent);
                }
                if (i == 2) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 3) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 4) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 5) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}








