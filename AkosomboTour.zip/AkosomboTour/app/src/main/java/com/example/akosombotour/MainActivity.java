package com.example.akosombotour;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    private ViewPager viewPager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = findViewById(R.id.viewpager);
        // setting up the adapter
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        //attaching fragments to adapter
        viewPagerAdapter.add(new HistoryFragment(), "History");
        viewPagerAdapter.add(new EthnicgroupsFragment(), "Ethnic Groups");
        viewPagerAdapter.add(new ToursitesFragment(), "Tour Site");
        viewPagerAdapter.add(new HotelsFragment(), "Hotels");
        //Set the adapter
        viewPager.setAdapter(viewPagerAdapter);
        // The Page (fragment) titles will be displayed in the
        tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
    }
}